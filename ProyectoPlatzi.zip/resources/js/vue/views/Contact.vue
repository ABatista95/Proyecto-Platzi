<template>
    <Header/>

    <div>
        <p>Área de contacto</p>
    </div>

    <Footer/>
</template>

<script>
import Header from '../components/home/Header'
import Footer from '../components/home/Footer'

export default {
    components: {
        Header,
        Footer
    }
}
</script>
