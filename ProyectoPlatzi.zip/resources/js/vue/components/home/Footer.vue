<template>
    <div>
        <p>Texto de FOOTER</p>
    </div>
</template>
